# Bottle > 2024-04-21 2:44pm
https://universe.roboflow.com/bottles-computer-vision/bottle-f67lg

Provided by a Roboflow user
License: Public Domain

